package miniproject;

import java.util.ArrayList;
import java.util.Scanner;

class Website {

    void home() {
        System.out.println("\n===== HOME PAGE =====");
        System.out.println("Welcome to Our Website!");
        System.out.println("We provide quality services.");
    }

    void about() {
        System.out.println("\n===== ABOUT US =====");
        System.out.println("This is a Core Java Mini Project.");
        System.out.println("Developed using OOP concepts.");
    }

    void services() {
        System.out.println("\n===== SERVICES =====");
        ArrayList<String> serviceList = new ArrayList<>();
        serviceList.add("1. Web Development");
        serviceList.add("2. App Development");
        serviceList.add("3. Java Training");

        for (String s : serviceList) {
            System.out.println(s);
        }
    }

    void contact() {
        System.out.println("\n===== CONTACT US =====");
        System.out.println("Email: info@website.com");
        System.out.println("Phone: 9876543210");
    }
}

public class  Websiteview {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Website site = new Website();
        int choice;

        
		do {
            System.out.println("\n===== WEBSITE MENU =====");
            System.out.println("1. Home");
            System.out.println("2. About");
            System.out.println("3. Services");
            System.out.println("4. Contact");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
              choice = sc.nextInt();
            


            switch (choice) {
                case 1:
                    site.home();
                    break;
                case 2:
                    site.about();
                    break;
                case 3:
                    site.services();
                    break;
                case 4:
                    site.contact();
                    break;
                case 5:
                    System.out.println("Thank you for visiting!");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 5);

        sc.close();
    }
}
 
